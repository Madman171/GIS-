# 腾讯云生产部署

目标环境：

```text
腾讯云 Ubuntu Server 26.04 LTS
地区：广州
临时公开地址：http://服务器公网IP:8080
```

Neo4j 和 FastAPI 仅在 Docker 内部网络运行，不向公网开放端口。
为支持本机 SSH 隧道，Neo4j 仅在服务器 `127.0.0.1` 上监听
`7474` 和 `7687`，腾讯云安全组仍不得开放这两个端口。

## 一、腾讯云安全组

入站规则至少开放：

| 端口 | 来源 | 用途 |
| ---: | --- | --- |
| 22 | 你的公网 IP | SSH 管理 |
| 8080 | 0.0.0.0/0 | 临时网站访问 |
| 80 | 0.0.0.0/0 | 备案和域名完成后使用 |
| 443 | 0.0.0.0/0 | HTTPS |

不要开放：

```text
7474
7687
8000
5173
```

## 二、安装 Docker

登录服务器后执行：

```bash
cd /opt/gis-knowledge-platform
chmod +x deploy/*.sh
./deploy/install-docker-ubuntu.sh
```

如果脚本把当前用户加入了 Docker 组，需要退出 SSH 后重新登录。

## 三、配置环境变量

```bash
cd /opt/gis-knowledge-platform/deploy
cp .env.production.example .env
nano .env
```

填写：

```dotenv
PUBLIC_PORT=8080
NEO4J_PASSWORD=高强度数据库密码
DEEPSEEK_API_KEY=你的DeepSeekKey
CORS_ALLOW_ORIGINS=http://服务器公网IP:8080
CHAT_RATE_LIMIT_PER_MINUTE=5
CHAT_RATE_LIMIT_WHITELIST=
KG_MAX_LEARNING_PATH_LENGTH=8
ENABLE_TOPOLOGY_CHECK=true
TOPOLOGY_COORDINATE_TOLERANCE=1.0
ANSWER_MAX_REFERENCES=6
```

`.env` 文件权限建议：

```bash
chmod 600 .env
```

## 四、一键部署

```bash
cd /opt/gis-knowledge-platform
./deploy/deploy.sh
```

脚本会：

1. 构建前后端镜像。
2. 启动 Neo4j。
3. 导入数据库快照。
4. 启动 FastAPI。
5. 启动 Nginx 前端。
6. 执行健康检查。

## 五、公开访问

浏览器打开：

```text
http://服务器公网IP:8080
```

后端健康检查：

```text
http://服务器公网IP:8080/api/health
```

## 六、常用命令

查看状态：

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml ps
```

查看日志：

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml logs -f
```

重启：

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml restart
```

停止：

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml down
```

健康检查：

```bash
./deploy/health-check.sh
```

备份：

```bash
./deploy/backup.sh
```

## 七、ICP 备案与域名

广州地域服务器需要使用已备案域名才能正式通过 80/443 提供网站。

当前 Nginx 运行在容器中，因此不要在宿主机直接执行 `certbot --nginx`。
备案完成并配置 DNS A 记录后，再生成 HTTPS Compose 覆盖配置，向容器
挂载证书并开放 80/443 端口。

正式域名的 `CORS_ALLOW_ORIGINS` 应修改为：

```dotenv
CORS_ALLOW_ORIGINS=https://gis.example.com
```

修改后执行：

```bash
docker compose --env-file deploy/.env -f deploy/docker-compose.yml up -d backend
```
